'use strict';
document.documentElement.classList.add('js');

const iconPaths = {
  'arrow-up-right':'<path d="M7 17 17 7M7 7h10v10"/>',
  'arrow-down-right':'<path d="m7 7 10 10M17 7v10H7"/>',
  'arrow-right':'<path d="M5 12h14m-7-7 7 7-7 7"/>',
  'check':'<path d="m5 12 4 4L19 6"/>',
  'check-circle':'<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
  'message-circle':'<path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5 8.5 8.5 0 0 1-4-.96L3 21l1.96-5.5a8.5 8.5 0 1 1 16.04-4Z"/>',
  'layout-dashboard':'<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>',
  'users':'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M16 3.13a4 4 0 0 1 0 7.75M22 21v-2a4 4 0 0 0-3-3.87"/><circle cx="9" cy="7" r="4"/>',
  'columns-3':'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 3v18M15 3v18"/>',
  'search':'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
  'git-branch':'<circle cx="6" cy="3" r="2"/><path d="M6 5v12a4 4 0 0 0 4 4h6"/><circle cx="18" cy="6" r="2"/><circle cx="18" cy="21" r="2"/><path d="M10 10h4a4 4 0 0 0 4-4"/>',
  'send':'<path d="m22 2-7 20-4-9-9-4Z M22 2 11 13"/>',
  'lock':'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
  'more-horizontal':'<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
  'calendar':'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18"/>',
  'trending-up':'<path d="m3 17 6-6 4 4 8-8M15 7h6v6"/>',
  'chart-no-axes-combined':'<path d="M3 3v18h18M7 17l4-5 4 3 5-8M16 7h4v4"/>',
  'filter':'<path d="M4 4h16l-6 7v7l-4 2v-9Z"/>',
  'sparkles':'<path d="m12 3 1.7 5.3L19 10l-5.3 1.7L12 17l-1.7-5.3L5 10l5.3-1.7L12 3ZM19 16l.7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7L19 16Z"/>',
  'play':'<path d="m8 5 11 7-11 7V5Z"/>',
  'info':'<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
  'asterisk':'<path d="M12 3v18M4.2 7.5l15.6 9M4.2 16.5l15.6-9"/>',
  'shield-check':'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/>',
  'target':'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  'building-2':'<rect x="3" y="8" width="10" height="13" rx="1"/><path d="M8 12h.01M8 16h.01M16 21V3h5v18M16 8h5M16 13h5M16 18h5M3 21h18"/>',
  'move':'<path d="m5 9-3 3 3 3M9 5l3-3 3 3M15 19l-3 3-3-3M19 9l3 3-3 3M2 12h20M12 2v20"/>',
  'file-text':'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z M14 2v6h6M8 13h8M8 17h8"/>',
  'zap':'<path d="m13 2-9 12h7l-1 8 10-12h-7l0-8Z"/>',
  'clock':'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2"/>',
  'bot':'<rect x="3" y="7" width="18" height="13" rx="3"/><path d="M12 3v4M9 3h6"/><circle cx="8" cy="13" r="1"/><circle cx="16" cy="13" r="1"/><path d="M9 17h6"/>',
  'layers':'<path d="m12 2 9 5-9 5-9-5 9-5ZM3 12l9 5 9-5M3 17l9 5 9-5"/>',
  'factory':'<path d="M3 21V9l6 4V9l6 4V3h6v18Z M3 21h18M7 17h.01M12 17h.01M17 17h.01"/>',
  'package':'<path d="m12 2 9 5-9 5-9-5 9-5ZM3 7v10l9 5 9-5V7M12 12v10"/>',
  'briefcase-business':'<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 13h18"/>',
  'handshake':'<path d="m2 10 5-5 4 2 3-2 8 7-3 4-3 1-3 3-4-1-4-4-3-1Z"/><path d="m7 13 5 5M10 10l3-3M13 14l4 3"/>',
  'plus':'<path d="M12 5v14M5 12h14"/>',
  'menu':'<path d="M4 7h16M4 12h16M4 17h16"/>'
};
function hydrateIcons(scope=document){scope.querySelectorAll('i[data-icon]').forEach(i=>{const path=iconPaths[i.dataset.icon];if(!path)return;i.innerHTML=`<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg>`;});}
hydrateIcons();

const menuToggle=document.getElementById('menuToggle'),navLinks=document.getElementById('navLinks');
menuToggle?.addEventListener('click',()=>{const open=navLinks.classList.toggle('open');menuToggle.setAttribute('aria-expanded',String(open));menuToggle.setAttribute('aria-label',open?'Fechar menu':'Abrir menu');});
navLinks?.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{navLinks.classList.remove('open');menuToggle.setAttribute('aria-expanded','false');menuToggle.setAttribute('aria-label','Abrir menu');}));
document.addEventListener('click',e=>{if(menuToggle&&!menuToggle.contains(e.target)&&navLinks&&!navLinks.contains(e.target)){navLinks.classList.remove('open');menuToggle.setAttribute('aria-expanded','false');}});

const progress=document.getElementById('scrollProgress');let scrollFrame=false;
function updateScroll(){const max=document.documentElement.scrollHeight-window.innerHeight;progress.style.width=`${max>0?Math.min(100,window.scrollY/max*100):0}%`;scrollFrame=false;}
window.addEventListener('scroll',()=>{if(!scrollFrame){requestAnimationFrame(updateScroll);scrollFrame=true;}},{passive:true});updateScroll();
if('IntersectionObserver' in window){const observer=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('revealed');observer.unobserve(entry.target);}})},{rootMargin:'0px 0px -30px 0px',threshold:.07});document.querySelectorAll('[data-reveal]').forEach(el=>observer.observe(el));}else{document.querySelectorAll('[data-reveal]').forEach(el=>el.classList.add('revealed'));}

// Demonstração local do extrator: não realiza requisições reais, nem expõe dados de clientes.
const searchForm=document.getElementById('demoSearchForm');const resultBody=document.getElementById('extractorResults');const countEl=document.getElementById('demoCount');const cityInput=document.getElementById('cityInput');const nicheInput=document.getElementById('nicheInput');
let activeContact='all';let activeQuantity=20;
const exampleCompanies={
  building:[
    {name:'Fortaleza Materiais',symbol:'F',dot:'',whatsapp:true},
    {name:'Constrular Depósito',symbol:'C',dot:'second',whatsapp:true},
    {name:'Ponto Forte Construção',symbol:'P',dot:'third',whatsapp:false},
    {name:'Casa do Construtor',symbol:'C',dot:'',whatsapp:true},
    {name:'Depósito Nova Obra',symbol:'D',dot:'second',whatsapp:true}
  ],
  gym:[
    {name:'Academia Impulso',symbol:'I',dot:'',whatsapp:true},
    {name:'Movimento Fitness',symbol:'M',dot:'second',whatsapp:true},
    {name:'Arena Training',symbol:'A',dot:'third',whatsapp:false},
    {name:'Forte Performance',symbol:'F',dot:'',whatsapp:true},
    {name:'Academia Energia',symbol:'E',dot:'second',whatsapp:true}
  ],
  other:[
    {name:'Grupo Horizonte',symbol:'H',dot:'',whatsapp:true},
    {name:'Atlas Comercial',symbol:'A',dot:'second',whatsapp:true},
    {name:'Vértice Negócios',symbol:'V',dot:'third',whatsapp:false},
    {name:'Nova Rota Empresas',symbol:'N',dot:'',whatsapp:true},
    {name:'Prime Soluções',symbol:'P',dot:'second',whatsapp:true}
  ]
};
function normalizedNiche(text){return text.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();}
function currentExampleCompanies(){const text=normalizedNiche(nicheInput.value);return /academia|fitness|musculacao|ginastica/.test(text)?exampleCompanies.gym:/construcao|material|deposito|ferragem/.test(text)?exampleCompanies.building:exampleCompanies.other;}
function syncNichePresets(){document.querySelectorAll('#nichePresets button').forEach(button=>{const selected=normalizedNiche(button.dataset.niche)===normalizedNiche(nicheInput.value.trim());button.classList.toggle('selected',selected);button.setAttribute('aria-pressed',String(selected));});}
document.querySelectorAll('#nichePresets button').forEach(button=>button.addEventListener('click',()=>{nicheInput.value=button.dataset.niche;syncNichePresets();updateExtractor();}));
nicheInput?.addEventListener('input',syncNichePresets);
function resultCell(row,text){const cell=document.createElement('td');cell.textContent=text;row.appendChild(cell);return cell;}
function updateExtractor(){const loc=cityInput.value.trim()||'Sua região';const companies=currentExampleCompanies();const items=activeContact==='wa'?companies.filter(c=>c.whatsapp):companies;resultBody.replaceChildren();items.slice(0,3).forEach(company=>{const tr=document.createElement('tr');const td=document.createElement('td');const avatar=document.createElement('span');avatar.className='company-dot '+company.dot;avatar.textContent=company.symbol;const bold=document.createElement('strong');bold.textContent=company.name;td.append(avatar,bold);tr.appendChild(td);resultCell(tr,loc);resultCell(tr,'(00) 00000-0000');const status=resultCell(tr,'');const chip=document.createElement('span');chip.className=company.whatsapp?'wa-chip':'neutral-chip';chip.textContent=company.whatsapp?'WhatsApp':'Telefone';status.appendChild(chip);const last=resultCell(tr,'');last.innerHTML='<i data-icon="arrow-up-right"></i>';resultBody.appendChild(tr);});hydrateIcons(resultBody);countEl.textContent=`${activeQuantity} ${activeContact==='wa'?'contatos WhatsApp':'empresas'} na simulação`;}
searchForm?.addEventListener('submit',e=>{e.preventDefault();updateExtractor();});
function initToggle(groupId,dataName,callback){const group=document.getElementById(groupId);group?.querySelectorAll('button').forEach(button=>button.addEventListener('click',()=>{group.querySelectorAll('button').forEach(other=>{const selected=other===button;other.classList.toggle('selected',selected);other.setAttribute('aria-pressed',String(selected));});callback(button.dataset[dataName]);updateExtractor();}));}
initToggle('contactFilters','filter',v=>activeContact=v);initToggle('quantityFilters','quantity',v=>activeQuantity=Number(v));

// Kanban em memória: interação visual somente, não persiste nem altera o CRM real.
const board=document.getElementById('kanbanBoard');let dragged=null;
function updateLanes(){board?.querySelectorAll('.kanban-column').forEach(lane=>{const count=lane.querySelectorAll('.deal-card').length;lane.querySelector('.lane-count').textContent=String(count);});}
function announceMove(card,lane){lane.querySelector('.lane-cards').appendChild(card);updateLanes();const status=document.getElementById('kanbanStatus');status.textContent=`${card.querySelector('b').textContent} movido para ${lane.querySelector('.lane-head strong').textContent} (simulação).`;}
board?.addEventListener('dragstart',e=>{const card=e.target.closest('.deal-card');if(!card)return;dragged=card;card.classList.add('dragging');e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',card.dataset.deal);});
board?.addEventListener('dragend',e=>{e.target.closest('.deal-card')?.classList.remove('dragging');board.querySelectorAll('.dragover').forEach(el=>el.classList.remove('dragover'));dragged=null;});
board?.querySelectorAll('.kanban-column').forEach(lane=>{lane.addEventListener('dragover',e=>{e.preventDefault();lane.classList.add('dragover');e.dataTransfer.dropEffect='move';});lane.addEventListener('dragleave',e=>{if(!lane.contains(e.relatedTarget))lane.classList.remove('dragover');});lane.addEventListener('drop',e=>{e.preventDefault();lane.classList.remove('dragover');const card=dragged||Array.from(board.querySelectorAll('.deal-card')).find(c=>c.dataset.deal===e.dataTransfer.getData('text/plain'));if(card)announceMove(card,lane);});});
board?.querySelectorAll('.deal-card').forEach(card=>card.addEventListener('keydown',e=>{if(e.key!=='ArrowRight'&&e.key!=='ArrowLeft')return;e.preventDefault();const lanes=Array.from(board.querySelectorAll('.kanban-column'));const current=lanes.indexOf(card.closest('.kanban-column'));const next=current+(e.key==='ArrowRight'?1:-1);if(lanes[next]){announceMove(card,lanes[next]);card.focus();}}));

const flowSamples={
  abordagem:{description:'Quando um novo lead entra em Prospecção, o fluxo pode iniciar a abordagem e acompanhar a resposta.',trigger:'Lead em Prospecção',send:'Olá! Posso apresentar uma solução para sua empresa?',condition:'Recebeu resposta?'},
  followup:{description:'Crie uma espera entre mensagens e mantenha o acompanhamento de oportunidades que ainda não responderam.',trigger:'Contato sem resposta',send:'Olá! Passando para retomar nossa conversa. Posso ajudar?',condition:'Respondeu ao retorno?'},
  ia:{description:'Direcione interações para um agente de IA configurado para qualificação, com opção de continuidade humana.',trigger:'Mensagem recebida',send:'Olá! Vou entender o que sua empresa procura.',condition:'Precisa de atendimento humano?'}
};
document.querySelectorAll('[data-flow]').forEach(tab=>tab.addEventListener('click',()=>{document.querySelectorAll('[data-flow]').forEach(t=>{const active=t===tab;t.classList.toggle('selected',active);t.setAttribute('aria-selected',String(active));t.tabIndex=active?0:-1;});const data=flowSamples[tab.dataset.flow];document.getElementById('flowDescription').textContent=data.description;document.getElementById('nodeTrigger').textContent=data.trigger;document.getElementById('nodeSend').textContent=data.send;document.getElementById('nodeCondition').textContent=data.condition;}));
document.querySelector('.flow-tabs')?.addEventListener('keydown',e=>{if(e.key!=='ArrowRight'&&e.key!=='ArrowLeft')return;const tabs=[...document.querySelectorAll('[data-flow]')];const current=tabs.indexOf(document.activeElement);if(current<0)return;e.preventDefault();const next=(current+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;tabs[next].focus();tabs[next].click();});

// FAQ: mantém apenas uma pergunta expandida, sem atrapalhar navegação por teclado.
document.querySelectorAll('.faq-items details').forEach(detail=>detail.addEventListener('toggle',()=>{if(detail.open)document.querySelectorAll('.faq-items details').forEach(other=>{if(other!==detail)other.open=false;});}));
